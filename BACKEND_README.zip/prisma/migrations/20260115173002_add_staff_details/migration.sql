-- AlterTable
ALTER TABLE `clinicstaff` ADD COLUMN `department` VARCHAR(191) NULL,
    ADD COLUMN `specialty` VARCHAR(191) NULL;
