-- AlterTable
ALTER TABLE `appointment` ADD COLUMN `service` VARCHAR(191) NULL;
