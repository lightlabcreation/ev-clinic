import { Router } from 'express';
import * as pharmacyController from '../controllers/pharmacy.controller.js';
import { protect, ensureClinicContext, requireModule } from '../middlewares/auth.js';

const router = Router();

router.use(protect);
router.use(ensureClinicContext);
router.use(requireModule('pharmacy'));

router.get('/inventory', pharmacyController.getInventory);
router.post('/inventory', pharmacyController.addInventory);
router.get('/orders', pharmacyController.getOrders);
router.post('/orders/process', pharmacyController.processOrder);
router.post('/pos', pharmacyController.directSale);

export default router;
