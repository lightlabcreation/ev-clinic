import { Router } from 'express';
import * as receptionController from '../controllers/reception.controller.js';
import { protect, restrictTo, ensureClinicContext } from '../middlewares/auth.js';

const router = Router();

router.use(protect, ensureClinicContext);

router.get('/stats', restrictTo('RECEPTIONIST', 'ADMIN'), receptionController.getStats);
router.get('/activities', restrictTo('RECEPTIONIST', 'ADMIN'), receptionController.getActivities);

router.get('/patients', receptionController.getPatients); // ensureClinicContext already ensures membership
router.post('/patients', restrictTo('RECEPTIONIST', 'ADMIN'), receptionController.createPatient);
router.patch('/patients/:id', restrictTo('RECEPTIONIST', 'ADMIN', 'DOCTOR', 'PHARMACY', 'LAB', 'RADIOLOGY'), receptionController.updatePatient);

router.get('/appointments', receptionController.getAppointments);
router.post('/appointments', restrictTo('RECEPTIONIST', 'ADMIN'), receptionController.createAppointment);

router.patch('/appointments/:id/status', restrictTo('RECEPTIONIST', 'ADMIN'), receptionController.updateApptStatus);

router.patch('/patients/:id/password', restrictTo('RECEPTIONIST', 'ADMIN'), receptionController.resetPassword);

export default router;
