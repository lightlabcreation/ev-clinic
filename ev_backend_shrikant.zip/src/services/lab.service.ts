import { prisma } from '../server.js';
import { AppError } from '../utils/AppError.js';

export const getLabOrders = async (clinicId: number, type: 'LAB' | 'RADIOLOGY') => {
    console.log(`[LAB/RAD] Fetching ${type} orders for clinic ${clinicId}`);

    // Normalize type for search
    const typeList = type === 'LAB' ? ['LAB', 'Laboratory', 'laboratory'] : ['RADIOLOGY', 'Radiology', 'radiology', 'RAD'];

    const orders = await prisma.service_order.findMany({
        where: {
            clinicId,
            type: { in: typeList }
        },
        include: {
            patient: { select: { name: true } }
        },
        orderBy: { createdAt: 'desc' }
    });

    console.log(`[LAB/RAD] Found ${orders.length} ${type} orders for clinic ${clinicId}`);
    return orders;
};

export const completeLabOrder = async (clinicId: number, orderId: number, data: any) => {
    const { result, price, paid } = data;

    return await prisma.$transaction(async (tx) => {
        const order = await tx.service_order.update({
            where: { id: orderId },
            data: {
                status: 'Completed',
                result: result // Can be JSON string or URL to report
            }
        });

        // Create Invoice for the test
        const invoice = await tx.invoice.create({
            data: {
                id: `${order.type === 'LAB' ? 'LAB' : 'RAD'}-${Math.floor(1000 + Math.random() * 9000)}`,
                clinicId,
                patientId: order.patientId,
                doctorId: order.doctorId,
                service: `${order.type}: ${order.testName}`,
                amount: Number(price),
                status: paid ? 'Paid' : 'Pending',
                date: new Date()
            }
        });

        // Store result AND invoice info in the order result field (as JSON)
        // If result was plain text, wrap it.
        const resultData = {
            findings: result,
            invoiceId: invoice.id,
            amount: Number(price),
            paid
        };

        await tx.service_order.update({
            where: { id: orderId },
            data: {
                result: JSON.stringify(resultData)
            }
        });

        return order;
    });
};

export const rejectLabOrder = async (clinicId: number, orderId: number) => {
    return await prisma.service_order.update({
        where: { id: orderId, clinicId },
        data: { status: 'Rejected' }
    });
};
