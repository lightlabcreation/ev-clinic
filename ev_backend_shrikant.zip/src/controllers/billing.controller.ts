import { Response } from 'express';
import { AuthRequest } from '../middlewares/auth.js';
import * as billingService from '../services/billing.service.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const getInvoices = asyncHandler(async (req: AuthRequest, res: Response) => {
    const invoices = await billingService.getInvoices(req.clinicId!);
    res.status(200).json({ status: 'success', data: invoices });
});

export const createInvoice = asyncHandler(async (req: AuthRequest, res: Response) => {
    const invoice = await billingService.createInvoice(req.clinicId!, req.body);
    res.status(201).json({ status: 'success', data: invoice });
});

export const updateInvoice = asyncHandler(async (req: AuthRequest, res: Response) => {
    const invoice = await billingService.updateInvoiceStatus(req.clinicId!, req.params.id as string, req.body.status);
    res.status(200).json({ status: 'success', data: invoice });
});
